-- Q2 A

select* from passengers where gender='F' and distance>=600;

-- Q2 B

select* from passengers where distance>=500 and bus_type='sleeper';

-- Q2 C 

select* from passengers where passenger_name like 's%';

-- Q2 D 
select * from passengers;
select * from price;
select passenger_name ,p1.boarding_city,p1.destination_city,p1.bus_type,p2.price from passengers p1,price p2  where p1.distance= p2.distance and p1.bus_type=p2.bus_type;

-- Q2 E

select p1.passenger_name,p1.bus_type,p2.price from passengers p1,price p2 where p1.distance=1000 and p1.bus_type='sitting';

-- Q2 F  


select * from passengers;
select* from price;
select * from passengers p join price pr 
on p.bus_type=pr.bus_type and p.distance=pr.distance
where p.passenger_name='pallavi' and p.boarding_city='bengaluru' and p.destination_city='panaji' and  p.bus_type in ('sitting','sleeper');


-- Q2 G 

update passengers set category ='Non-AC' where bus_type='sleeper';
select * from passengers;

-- Q2 H 

delete from passengers where passenger_name='piyush';
commit;

-- Q2 I
 
select count(*) from passengers; 
truncate passengers;
select count(*) from passengers; #The out put will be 0 because when we do truncate all rows have been deleted


-- Q2 J

drop table passengers;